from distutils.core import setup

setup(
    name='camel_ci_python',
    version='0.2',
    packages=['camel_bubblesort',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    description="Python package for ISEP CI project",
    url="https://github.com/camel-ci/camel-cli",
    long_description=open('README.txt').read(),
)
