This package developped for our CI/CD project writes in a file every XX seconds an array of 10 random numbers and this array sorted by increasing numbers

How to install and launch (we suppose that python 3 is already installed) :

1) Install package :
$ pip install pathToDownloadedFile/camel_ci_python-0.2.tar.gz

2) Test Package :
$ python camel_bubblesort.TestBubblesort

3) Launch in background :
python -m camel_bubblesort.bubblesort &

